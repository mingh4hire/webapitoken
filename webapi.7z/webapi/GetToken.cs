﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace webapi
{
    public class GetToken
    {
        public String GetTokenString(string UserName)
        {
            string claimValue = "b";
            var claims = new[]
            {
                new Claim("ClaimName", claimValue),
                new Claim("UserName", UserName)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("asdfasdfadsffasdsdfafsdasdf"));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: "c",
                audience: "d",
                claims: claims,
                expires: DateTime.UtcNow.AddYears(Convert.ToInt32(15)),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
            
        }
            
    }
}
