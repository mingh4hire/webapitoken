﻿using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;
using Serilog;
using Microsoft.AspNetCore.Authentication.JwtBearer;
// using Microsoft.AspNetCore.Authentication.JwtBearer;


namespace DepotOpsApi.Controllers
{
    [Route("api/[controller]")]
    [Route("api/v1/jwt")]
    public class JWTTokenController : ControllerBase
    {
        public JWTTokenController(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IConfiguration Configuration { get; }

        // [AllowAnonymous]
        //[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Policy = "depotOps")]
        [HttpGet("token")]
        public IActionResult RequestToken([FromQuery] string request)
        {
            string claimValue = "b";
            var claims = new[]
            {
                new Claim("ClaimName", claimValue)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("asdfasdfadsffasdsdfafsdasdf"));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: "c",
                audience: "d",
                claims: claims,
                expires: DateTime.UtcNow.AddYears(Convert.ToInt32(request)),
                signingCredentials: creds);

            return Ok(new
            {
                token = new JwtSecurityTokenHandler().WriteToken(token)
            });
        }


        public class TokenRequest
        {
            public string UserId { get; set; }
            public string AccessKey { get; set; }
            public string ClaimValue { get; set; }
        }
    }


}