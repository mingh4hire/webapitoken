﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace webapi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Policy = "askGet")]
    public class ValuesController : ControllerBase
    {
        [HttpGet]
        public int GetANumber()
        {
            return 3;
        }
        [HttpGet("GetANumber")]

        public string GetANumberString()
        {
            string name = "";
            name = HttpContext.User.Claims.Where(x => x.Type == "ClaimName").FirstOrDefault().Value;
            return 3 + name;
        }


    }
}
